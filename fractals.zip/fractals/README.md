# Project 1

## Members
|Name     | x500|
|----------|---------|
|Zeel Patel | Patel710 |
|Lubna Mohamed | moha0825|
## Instructions 
1.) Open Fractals.java file
2.) Run Fractals.java file and enter the shape you would like (either a Circle, Triangle, or Rectangle)
3.) Go to terminal to see the calculated area of shape you selected.


